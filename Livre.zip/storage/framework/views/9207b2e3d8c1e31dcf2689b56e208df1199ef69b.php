<!DOCTYPE html>
<html lang="fra">
    <head>
        <?php echo $__env->yieldContent('style'); ?> <?php echo $__env->make('layouts/partials/_entete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>

    <body>
        <!--Page Preloder-->
        <div id = "preloder">
            <div class = "loader"></div>
        </div>
        <!--Humberger Begin-->
        <?php echo $__env->make('layouts/partials/_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--Humberger End-->
        <!--Header Section Begin-->
        <?php echo $__env->make('layouts/partials/_navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--Header Section End-->
        <!--Hero Section Begin-->
        <?php echo $__env->make('layouts/partials/_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--Hero Section End-->
        <?php echo $__env->yieldContent('contenu'); ?>
        <!--footer Section Begin-->
        <?php echo $__env->make('layouts/partials/_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!--footer Section End-->
        <!--Js Plugins-->
        <?php echo $__env->make('layouts/partials/_script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>

</html><?php /**PATH C:\laragon\www\Livre\resources\views/layouts/master.blade.php ENDPATH**/ ?>